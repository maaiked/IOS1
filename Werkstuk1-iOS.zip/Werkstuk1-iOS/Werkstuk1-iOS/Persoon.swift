//
//  Persoon.swift
//  Werkstuk1-iOS
//
//  Created by Maaike Dupont on 28/05/2019.
//  Copyright © 2019 Maaike Dupont. All rights reserved.
//

import UIKit
import MapKit

// code from : stackoverflow.com/questions/24003191/pick-a-random-element-from-an-array
extension Array {
    func randomItem() -> Element? {
        if isEmpty { return nil }
        let index = Int(arc4random_uniform(UInt32(self.count)))
        return self[index]
    }
}

class Persoon {
    
    // MARK: properties
    
    var naam: String
    var voornaam: String
    var foto: UIImage?
    var straat: String
    var huisnummer: String
    var postcode: String
    var gemeente: String
    var gps: MyAnnotation
    var telefoonnummer: String
    
    var fotos = [#imageLiteral(resourceName: "images-2.jpeg"), #imageLiteral(resourceName: "images-4"), #imageLiteral(resourceName: "images-3"), #imageLiteral(resourceName: "images.jpeg")]
    var locaties: [CLLocationCoordinate2D] = [CLLocationCoordinate2DMake(50.861670, 3.305829), CLLocationCoordinate2DMake(51.861670, 3.315829), CLLocationCoordinate2DMake(50.861670, 3.305829), CLLocationCoordinate2DMake(50.845252, 3.311154), CLLocationCoordinate2DMake(50.845270, 3.300154),    CLLocationCoordinate2DMake(50.855270, 3.300254), CLLocationCoordinate2DMake(50.845370, 3.300354), CLLocationCoordinate2DMake(50.849270, 3.300454), CLLocationCoordinate2DMake(50.945270, 3.300554), CLLocationCoordinate2DMake(50.815270, 3.301154), CLLocationCoordinate2DMake(50.845210, 3.302154),    CLLocationCoordinate2DMake(50.841270, 3.303154), CLLocationCoordinate2DMake(50.842270, 3.304154), CLLocationCoordinate2DMake(50.843270, 3.305154)]

    
    
    // MARK : Initialization
    
    init?(naam: String, voornaam: String, straat: String, huisnummer: String, postcode: String, gemeente: String, telefoonnummer: String) {
        
        guard !naam.isEmpty else { return nil}
        guard !voornaam.isEmpty else { return nil}
        guard !straat.isEmpty else { return nil}
        guard !huisnummer.isEmpty else { return nil}
        guard !postcode.isEmpty else { return nil}
        guard !gemeente.isEmpty else { return nil}
        guard !telefoonnummer.isEmpty else { return nil}
        
        self.naam = naam
        self.voornaam = voornaam
        self.straat = straat
        self.huisnummer = huisnummer
        self.postcode = postcode
        self.gemeente = gemeente
        self.telefoonnummer = telefoonnummer
        self.foto = fotos.randomItem()
        self.gps = MyAnnotation(coordinate: locaties.randomItem()!, title: naam)
        
    }
}
