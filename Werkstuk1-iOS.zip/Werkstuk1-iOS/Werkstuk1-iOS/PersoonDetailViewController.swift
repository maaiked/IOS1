//
//  PersoonDetailViewController.swift
//  Werkstuk1-iOS
//
//  Created by Maaike Dupont on 28/05/2019.
//  Copyright © 2019 Maaike Dupont. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class PersoonDetailViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {
    
    // MARK : properties
    
    @IBOutlet weak var naamLabel: UILabel!
    @IBOutlet weak var voornaamLabel: UILabel!
    @IBOutlet weak var telefoonnummerLabel: UILabel!
    @IBOutlet weak var straatLabel: UILabel!
    @IBOutlet weak var fotoImage: UIImageView!
    @IBOutlet weak var gemeenteLabel: UILabel!
    @IBOutlet weak var huisnummerLabel: UILabel!
    @IBOutlet weak var kaartMap: MKMapView!
    @IBOutlet weak var postcodeLabel: UILabel!
    
    var persoon: Persoon?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let persoon = persoon {
            naamLabel.text = persoon.naam
            voornaamLabel.text = persoon.voornaam
            telefoonnummerLabel.text = persoon.telefoonnummer
            straatLabel.text = persoon.straat
            huisnummerLabel.text = persoon.huisnummer
            postcodeLabel.text = persoon.postcode
            gemeenteLabel.text = persoon.gemeente
            fotoImage.image = persoon.foto
            
            kaartMap.addAnnotation(persoon.gps)
            let center = CLLocationCoordinate2D(latitude: persoon.gps.coordinate.latitude, longitude: persoon.gps.coordinate.longitude)
            let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
            kaartMap.setRegion(region, animated: true)
            
        }
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        if segue.identifier == "showPhoto" {
            if let fotoViewController = segue.destination as? FotoViewController {
                fotoViewController.foto = persoon?.foto
            }
        }
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    

}
