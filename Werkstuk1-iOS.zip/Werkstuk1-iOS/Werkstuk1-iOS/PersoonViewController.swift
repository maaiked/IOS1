//
//  PersoonViewController.swift
//  Werkstuk1-iOS
//
//  Created by Maaike Dupont on 28/05/2019.
//  Copyright © 2019 Maaike Dupont. All rights reserved.
//
// Manual used : developer.apple.com: Start Developing iOS Apps (Swift)

import UIKit
import os.log

class PersoonViewController: UIViewController, UITextFieldDelegate, UINavigationControllerDelegate {
    // MARK: properties
    
    @IBOutlet weak var saveButton: UIBarButtonItem!
    @IBOutlet weak var naamLabel: UILabel!
    @IBOutlet weak var naamTextField: UITextField!
    @IBOutlet weak var voornaamLabel: UILabel!
    @IBOutlet weak var voornaamTextField: UITextField!
    @IBOutlet weak var fotoImageView: UIImageView!
    @IBOutlet weak var straatTextField: UITextField!
    @IBOutlet weak var telefoonnummerTextField: UITextField!
    @IBOutlet weak var gemeenteTextField: UITextField!
    @IBOutlet weak var postcodeTextField: UITextField!
    @IBOutlet weak var huisnummerTextField: UITextField!
    
    var persoon: Persoon?
    
    

    
    // MARK : navigation
    
    @IBAction func cancel(_ sender: UIBarButtonItem) {
    dismiss(animated: true, completion: nil)
    }
    
    
    //This method lets you configure a view controller before it's presented
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for:segue, sender: sender)
        
        // configure destination view controller only when save button is pressed
        guard let button = sender as? UIBarButtonItem, button === saveButton else { os_log("De save button was niet ingedrukt, cancelling", log: OSLog.default, type: .debug)
            return
        }
      
        let naam = naamTextField.text ?? ""
        let voornaam = voornaamTextField.text ?? ""
        let straat = straatTextField.text ?? ""
        let huisnummer = huisnummerTextField.text ?? ""
        let postcode = postcodeTextField.text ?? ""
        let gemeente = gemeenteTextField.text ?? ""
        let telefoonnummer = telefoonnummerTextField.text ?? ""
        
        persoon = Persoon(naam: naam, voornaam: voornaam, straat: straat, huisnummer: huisnummer, postcode: postcode, gemeente: gemeente, telefoonnummer: telefoonnummer)
    }
    
    
    override func viewDidLoad() {
super.viewDidLoad()
        naamTextField.delegate = self
        voornaamTextField.delegate = self
        straatTextField.delegate = self
        huisnummerTextField.delegate = self
        postcodeTextField.delegate = self
        gemeenteTextField.delegate = self
        telefoonnummerTextField.delegate = self
}

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
}
    // MARK : UITextFieldDelegate
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
        
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
    }
    
}
