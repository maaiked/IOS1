//
//  MyAnnotation.swift
//  Werkstuk1-iOS
//
//  Created by Maaike Dupont on 30/05/2019.
//  Copyright © 2019 Maaike Dupont. All rights reserved.
//

import Foundation
import MapKit

class MyAnnotation: NSObject, MKAnnotation {
    var coordinate: CLLocationCoordinate2D
    var title: String?
    
    init(coordinate: CLLocationCoordinate2D, title: String)
    {
        self.coordinate = coordinate
        self.title = title
    }
}
