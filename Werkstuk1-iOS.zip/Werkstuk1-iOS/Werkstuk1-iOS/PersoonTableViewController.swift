//
//  PersoonTableViewController.swift
//  Werkstuk1-iOS
//
//  Created by Maaike Dupont on 28/05/2019.
//  Copyright © 2019 Maaike Dupont. All rights reserved.
//

import UIKit
import os.log

var personen = [Persoon]()

class PersoonTableViewController: UITableViewController {

    //MARK: properties
    
    
    
    // MARK : Actions
    @IBAction func unwindToPersonList(sender: UIStoryboardSegue){
        if let sourceViewController = sender.source as? PersoonViewController, let persoon = sourceViewController.persoon {
            let newIndexPath = IndexPath(row: personen.count, section: 0)
            personen.append(persoon)
            tableView.insertRows(at: [newIndexPath], with: .automatic)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.leftBarButtonItem = editButtonItem
        
        loadSamplePersonen()
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

          }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return personen.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cellIdentifier = "PersoonInfoTableViewCell"
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? PersoonInfoTableViewCell else { fatalError("The dequeued cell is not an instance of PersoonInfoTableViewCell.")}
        
        let persoon = personen[indexPath.row]
        
        cell.voornaamLabel.text = persoon.voornaam
        cell.naamLabel.text = persoon.naam
        cell.fotoImageView.image = persoon.foto

        return cell
    }
    

    
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
 

    
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            personen.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        
        switch(segue.identifier ?? "") {
            
        case "AddItem":
            os_log("Adding a new person.", log: OSLog.default, type: .debug)
        
        case "ShowDetail":
            guard let persoonDetailViewController = segue.destination as? PersoonDetailViewController else { fatalError("Unexpected destination \(segue.destination)")}
            guard let selectedPersoonCell = sender as? PersoonInfoTableViewCell else { fatalError("Unexpected sender: \(sender)")}
            guard let indexPath = tableView.indexPath(for: selectedPersoonCell) else { fatalError("The selected cell is not being displayed by the table")}
            let selectedPersoon = personen[indexPath.row]
            persoonDetailViewController.persoon = selectedPersoon
            
        default: fatalError("Unexpected Segue Identifier: \(segue.identifier)")
            
        }
        
        
    }
    
    
    //MARK: private methods
    private func loadSamplePersonen() {
        
        guard let persoon1 = Persoon(naam: "Dupont", voornaam: "Maaike", straat: "Condédreef", huisnummer: "63", postcode: "8500", gemeente: "Kortrijk", telefoonnummer: "0471890604") else { fatalError("Kon geen persoon1 object maken")}
        guard let persoon2 = Persoon(naam: "Delombaerde", voornaam: "Manuel", straat: "Nieuwstraat", huisnummer: "10", postcode: "8530", gemeente: "Harelbeke", telefoonnummer: "0477889900") else { fatalError("Kon geen persoon2 object maken")}
        guard let persoon3 = Persoon(naam: "Bruggeman", voornaam: "Kevin", straat: "Dezestraat", huisnummer: "66", postcode: "8710", gemeente: "Oostrozebeke", telefoonnummer: "0478965432") else { fatalError("Kon geen persoon object maken")}
        guard let persoon4 = Persoon(naam: "Decock", voornaam: "Robbin", straat: "Teststraat", huisnummer: "47A", postcode: "8700", gemeente: "Tielt", telefoonnummer: "056707070") else { fatalError("Kon geen persoon object maken")}
        guard let persoon5 = Persoon(naam: "Decock", voornaam: "Olivia", straat: "Twee-Bruggenstraat", huisnummer: "30", postcode: "8530", gemeente: "Harelbeke", telefoonnummer: "0477800900") else { fatalError("Kon geen persoon object maken")}
        guard let persoon6 = Persoon(naam: "Dupont", voornaam: "Rik", straat: "Vlaanderenlaan", huisnummer: "9", postcode: "8530", gemeente: "Harelbeke", telefoonnummer: "0477888900") else { fatalError("Kon geen persoon object maken")}
        guard let persoon7 = Persoon(naam: "Devos", voornaam: "Julie", straat: "Hoogleedsesteenweg", huisnummer: "10", postcode: "8800", gemeente: "Roeselare", telefoonnummer: "0477889944") else { fatalError("Kon geen persoon object maken")}
        
        personen += [persoon1, persoon2, persoon3, persoon4, persoon5, persoon6, persoon7]
    }


}
