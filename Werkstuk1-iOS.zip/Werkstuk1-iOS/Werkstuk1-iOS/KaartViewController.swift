//
//  KaartViewController.swift
//  Werkstuk1-iOS
//
//  Created by Maaike Dupont on 30/05/2019.
//  Copyright © 2019 Maaike Dupont. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit

class KaartViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {
    
    
    
    
    // MARK : properties
    var locationManager = CLLocationManager()
    
    
    
    
    
    @IBOutlet weak var mapView: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        for persoon in personen {
        mapView.addAnnotation(persoon.gps)
        }
        
        locationManager.delegate = self
        locationManager.requestAlwaysAuthorization()
        if CLLocationManager.authorizationStatus() == .notDetermined {
            locationManager.requestWhenInUseAuthorization()
        }
        locationManager.startUpdatingLocation()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // https://appsandbiscuits.com/getting-the-users-location-ios-15-fe0a63be085b
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let location = locations.first!
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate, 1800, 1800)
        mapView.setRegion(coordinateRegion, animated: true)
        locationManager.stopUpdatingLocation()
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
